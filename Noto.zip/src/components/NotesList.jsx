import React from "react";
export function NotesList({children}) {
    return (
        <div className="notes-list">
            {children}
        </div>
    );
}
